public class DuplicateElementException extends Exception {
}
